export interface Post {
  title: string;
  content: string;
}
