import { Injectable } from '@angular/core';
import { CommonService } from './common.service';
import { Observable,Subject} from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class ChatServiceService {
  messages: Subject<any>;
  constructor( private commonService: CommonService) {   

     /*  this.commonService.connect().subscribe((res:any) =>{
        return res;
      }) */
  }

  

 
  
 
  
  // Our simplified interface for sending
  // messages back to our socket.io server
  sendMsg(msg) {
    this.messages.next(msg);
  }

}
