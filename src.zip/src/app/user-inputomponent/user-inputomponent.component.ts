import { Component, OnInit } from '@angular/core';
import { CommonService } from "../service/common.service";

@Component({
  selector: 'app-user-inputomponent',
  templateUrl: './user-inputomponent.component.html',
  styleUrls: ['./user-inputomponent.component.css']
})
export class UserInputomponentComponent implements OnInit {

 
  constructor(private _commonService:CommonService) { 
    
  }

  ngOnInit() {
  }

 /*  sendInput(){
  
  let output =  this._commonService.connectToSocket('RMS Team Member');
  console.log(output,'recieved')
  } */
}
