import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserInputomponentComponent } from './user-inputomponent.component';

describe('UserInputomponentComponent', () => {
  let component: UserInputomponentComponent;
  let fixture: ComponentFixture<UserInputomponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserInputomponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserInputomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
