import { Component, OnInit } from '@angular/core';
import { ChatServiceService } from 'src/app/service/chat-service.service';
import { CommonService } from 'src/app/service/common.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  constructor(private chat: ChatServiceService,private common:CommonService){ }
  message: string;
  messages: string[] = [];
  ngOnInit() {
    this.common
      .getMessages()
      .subscribe((message: string) => {
        this.messages.push(message);
      });
   
  }
  sendMessage() {
    this.common.sendMessage(this.message);
    this.message = '';
  }
  


}
