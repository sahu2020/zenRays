import { Component, OnInit } from '@angular/core';
import { ChatServiceService } from 'src/app/service/chat-service.service';
import { CommonService } from 'src/app/service/common.service';
@Component({
  selector: 'app-main-chat-window',
  templateUrl: './main-chat-window.component.html',
  styleUrls: ['./main-chat-window.component.css']
})
export class MainChatWindowComponent implements OnInit {

  constructor(private chat: CommonService) { }

  ngOnInit() {
    this.chat.connect().subscribe(msg => {
      console.log(msg);
    })
  }

  
}
